<?php
session_start();

// if(isset($_GET['logout']) && $_GET['logout'] === 'true') {
//     // Unset all of the session variables
//     $_SESSION = array();

//     // Destroy the session
//     session_destroy();

//     // Redirect to login page
//     header("Location: login.php");
//     exit;
// }
// Check if the user is already logged in, redirect to admin panel if so
// if(isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
//     header("Location: admin_panel.php");
//     exit;
// }

// Check if the form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check credentials (replace with your actual credentials validation logic)
    $username = "admin"; // Replace with your actual admin username
    $password = "admin123"; // Replace with your actual admin password

    $input_username = $_POST['username'];
    $input_password = $_POST['password'];

    if($input_username === $username && $input_password === $password) {
        // Valid credentials, set session variables and redirect to admin panel
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin_panel.php");
        exit;
    } else {
        // Invalid credentials, show error message
        $error_message = "Invalid username or password.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background-color: #f4f4f4;
}

h3 {
    text-align: center;
}

form {
    max-width: 300px;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

label {
    display: block;
    font-weight: bold;
    margin-bottom: 5px;
}

input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
    margin-bottom: 10px;
}

button[type="submit"] {
    background-color: #556b2f; /* Olive dark green */
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    width: 100%;
}

button[type="submit"]:hover {
    background-color: #8b4513; /* Saddle brown */
}

    </style>
</head>
<body>
    <h3>Login</h3>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <div>
            <button type="submit">Login</button>
        </div>
    </form>
    <?php if(isset($error_message)) { echo "<p style='color: red;'>$error_message</p>"; } ?>
</body>
</html>
