<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_reservation";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, 3307);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get form data
$name = $_POST['name'];
$email = $_POST['email'];
$rating = $_POST['rating'];
$comment = $_POST['comment'];

// Insert feedback into database
$sql = "INSERT INTO feedback (name, email, rating, comment) VALUES ('$name', '$email', '$rating', '$comment')";

if ($conn->query($sql) === TRUE) {
    echo "<center><p style='color:green; font-weight:bold; font-size:25px;padding-top:100px;'>Feedback submitted successfully</p></center>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
