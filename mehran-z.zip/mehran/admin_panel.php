<?php
session_start();

// Check if the user is logged in, redirect to login page if not
if(!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit;
}
if(isset($_GET['logout']) && $_GET['logout'] === 'true') {
    // Unset all of the session variables
    $_SESSION = array();

    // Destroy the session
    session_destroy();

    // Redirect to login page
    header("Location: login.php");
    exit;
}

// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_reservation";

$conn = new mysqli($servername, $username, $password, $dbname, 3307);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
// Today's reservations
$today = date("Y-m-d");
$sql_today = "SELECT COUNT(*) AS num_reservations_today FROM reservations WHERE reservation_date = '$today'";
$result_today = $conn->query($sql_today);
$row_today = $result_today->fetch_assoc();
$num_reservations_today = $row_today['num_reservations_today'];

// Number of reservations this month
$current_month_start = date("Y-m-01");
$current_month_end = date("Y-m-t");
$sql_current_month = "SELECT COUNT(*) AS num_reservations_current_month FROM reservations WHERE reservation_date BETWEEN '$current_month_start' AND '$current_month_end'";
$result_current_month = $conn->query($sql_current_month);
$row_current_month = $result_current_month->fetch_assoc();
$num_reservations_current_month = $row_current_month['num_reservations_current_month'];

// Last month's reservations
$last_month_start = date("Y-m-d", strtotime("first day of last month"));
$last_month_end = date("Y-m-d", strtotime("last day of last month"));
$sql_last_month = "SELECT COUNT(*) AS num_reservations_last_month FROM reservations WHERE reservation_date BETWEEN '$last_month_start' AND '$last_month_end'";
$result_last_month = $conn->query($sql_last_month);
$row_last_month = $result_last_month->fetch_assoc();
$num_reservations_last_month = $row_last_month['num_reservations_last_month'];

// Last year's reservations
$last_year_start = date("Y-m-d", strtotime("first day of January last year"));
$last_year_end = date("Y-m-d", strtotime("last day of December last year"));
$sql_last_year = "SELECT COUNT(*) AS num_reservations_last_year FROM reservations WHERE reservation_date BETWEEN '$last_year_start' AND '$last_year_end'";
$result_last_year = $conn->query($sql_last_year);
$row_last_year = $result_last_year->fetch_assoc();
$num_reservations_last_year = $row_last_year['num_reservations_last_year'];

// Function to delete a reservation
if(isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM reservations WHERE id=$delete_id";
    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("Reservation deleted successfully."); window.location.href = "admin_panel.php";</script>';
    } else {
        echo "Error deleting record: " . $conn->error;
    }
}

// Function to update a reservation
if(isset($_POST['update'])) {
    $update_id = $_POST['update_id'];
    $customer_name = $_POST['customer_name'];
    $customer_contact = $_POST['customer_contact'];
    $table_number= $_POST['table_number'];
    $reservation_date = $_POST['reservation_date'];
    $reservation_time = $_POST['reservation_time'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];

    $sql = "UPDATE reservations SET customer_name='$customer_name', customer_contact='$customer_contact', table_number='$table_number', reservation_date='$reservation_date', reservation_time='$reservation_time', start_time='$start_time', end_time='$end_time' WHERE id=$update_id";
    if ($conn->query($sql) === TRUE) {
        echo '<script>alert("Reservation updated successfully."); window.location.href = "admin_panel.php";</script>';
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

// Retrieve reservations from the database
$sql = "SELECT * FROM reservations";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <style>
        body {
            background-color:  #556B2F;
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background-color: #f4f4f4;
}

h3 {
    text-align: center;
}

table {
    width: 100%;
    border-collapse: collapse;
}

table, th, td {
    border: 1px solid #ddd;
    padding: 8px;
    text-align: left;
}

th {
    background-color: #556b2f; /* Olive dark green */
    color: #fff;
}

tr:nth-child(even) {
    background-color: #f2f2f2;
}

tr:hover {
    background-color: #ddd;
}

a {
    text-decoration: none;
    color: #556b2f; /* Olive dark green */
    margin-right: 10px;
}

a:hover {
    text-decoration: underline;
    color: #8b4513; /* Saddle brown */
}
.logout-btn {
            position: absolute;
            top: 20px;
            right: 20px;
        }

    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>


<body>
<a href="?logout=true" class="logout-btn">Logout</a>
    <h3>Admin Panel - Reservations</h3>
    <canvas id="reservationsChart" width="400" height="200"></canvas>
<script>
    var ctx = document.getElementById('reservationsChart').getContext('2d');
    var reservationsChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Today', 'This Month', 'Last Month', 'Last Year'],
            datasets: [{
                label: 'Number of Reservations',
                data: [<?php echo $num_reservations_today; ?>, <?php echo $num_reservations_current_month; ?>, <?php echo $num_reservations_last_month; ?>, <?php echo $num_reservations_last_year; ?>],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(75, 192, 192, 0.2)'
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(75, 192, 192, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: true
                    }
                }]
            }
        }
    });
</script>

    <table>
    <tr>
        <th>Time Period</th>
        <th>Number of Reservations</th>
    </tr>
    <tr>
        <td>Today</td>
        <td><?php echo $num_reservations_today; ?></td>
    </tr>
    <tr>
        <td>This Month</td>
        <td><?php echo $num_reservations_current_month; ?></td>
    </tr>
    <tr>
        <td>Last Month</td>
        <td><?php echo $num_reservations_last_month; ?></td>
    </tr>
    <tr>
        <td>Last Year</td>
        <td><?php echo $num_reservations_last_year; ?></td>
    </tr>
</table>

    <!-- Display reservations in a table -->
    <table>
        <tr>
            <th>ID</th>
            <th>Customer Name</th>
            <th>Contact</th>
            <th>Table Number</th>
            <th>Date</th>
            <th>Reservation Time</th>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Actions</th>
        </tr>
        <?php
        if ($result->num_rows > 0) {
            // Output data of each row
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>".$row["id"]."</td>";
                echo "<td>".$row["customer_name"]."</td>";
                echo "<td>".$row["customer_contact"]."</td>";
                echo "<td>".$row["table_number"]."</td>";
                echo "<td>".$row["reservation_date"]."</td>";
                echo "<td>".$row["reservation_time"]."</td>";
                echo "<td>".$row["start_time"]."</td>";
                echo "<td>".$row["end_time"]."</td>";
                echo "<td>
                        
                        <a href='admin_panel.php?delete_id=".$row["id"]."' onclick=\"return confirm('Are you sure you want to delete this reservation?')\">Delete</a>
                      </td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='9'>No reservations found</td></tr>";
        }
        ?>
    </table>
    <h3>Feedbacks</h3>
<table>
    <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Rating</th>
        <th>Comment</th>
    </tr>
    <?php
    // Retrieve feedbacks from the database
    $sql_feedback = "SELECT * FROM feedback";
    $result_feedback = $conn->query($sql_feedback);

    if ($result_feedback->num_rows > 0) {
        // Output data of each row
        while($row_feedback = $result_feedback->fetch_assoc()) {
            echo "<tr>";
            echo "<td>".$row_feedback["id"]."</td>";
            echo "<td>".$row_feedback["name"]."</td>";
            echo "<td>".$row_feedback["email"]."</td>";
            echo "<td>".$row_feedback["rating"]."</td>";
            echo "<td>".$row_feedback["comment"]."</td>";
            echo "</tr>";
        }
    } else {
        echo "<tr><td colspan='5'>No feedbacks found</td></tr>";
    }
    ?>
</table>

</body>
</html>

<?php
$conn->close();
?>
