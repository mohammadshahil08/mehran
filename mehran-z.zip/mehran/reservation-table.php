<?php
session_start();
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_reservation";

$conn = new mysqli($servername, $username, $password, $dbname, 3307);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
// Form data
$customer_name = $_POST['customer_name'];
$customer_contact = $_POST['customer_contact'];
$table_number= $_POST['table_number'];
$reservation_date = $_POST['reservation_date'];
$reservation_time = $_POST['reservation_time'];
$start_time = $_POST['start_time'];
$end_time = $_POST['end_time'];

// Check availability within the specified time range
$sql = "SELECT * FROM reservations WHERE reservation_date = '$reservation_date' AND ((reservation_time >= '$start_time' AND reservation_time <= '$end_time') OR (reservation_time <= '$start_time' AND end_time >= '$start_time')) AND table_number='$table_number'";
$result = $conn->query($sql);


if ($result->num_rows > 0) {
    $_SESSION['reservation_message'] = "Table not available for the selected date and time.";
} else {
    // Insert reservation into database
    $sql = "INSERT INTO reservations (customer_name, customer_contact, table_number, reservation_date, reservation_time, start_time, end_time) VALUES ('$customer_name', '$customer_contact', '$table_number', '$reservation_date', '$reservation_time', '$start_time', '$end_time')";
    if ($conn->query($sql) === TRUE) {
        $_SESSION['reservation_message'] = "Table reserved successfully.";
    } else {
        $_SESSION['reservation_message'] = "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Redirect back to this page to prevent form resubmission
header("Location: {$_SERVER['PHP_SELF']}");
exit();
}
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Table Reservation</title>
    <link rel="stylesheet" href="templates/style.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.1.0/fonts/remixicon.css" rel="stylesheet"/>
    <style>
        body {
            font-family: 'Outfit';
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
            
        }
        .res{
            background-color: black;
            height:40px;
        }
        .res h2 {
            font-size:30px;
            text-align: center;
            color:#BDBB70;
            font-family:'New Rocker';
            padding:1px;
        }
        
        .reservation-form {
            margin-top:5%;
            margin-left:30%;
            margin-bottom:5%;
            max-width: 600px;
            /* margin: 0 auto; */
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display:block;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        input[type="text"],
        input[type="date"],
        input[type="time"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
    box-sizing: border-box;
}

.btn-submit {
    background-color: #4CAF50;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    font-size: 16px;
    margin-top: 10px;
    width: 100%;
}

.btn-submit:hover {
    background-color: #45a049;
}
.popup {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            padding: 20px;
            background: black;
            color: #BDBB70; /* Default color for error message */
            font-weight: 900;
            font-size: 30px;
            font-family: 'Outfit';
            border: 2px solid darkgoldenrod; /* Default color for error message */
            border-radius: 10px;
            z-index: 9999;
            display: <?php echo isset($_SESSION['reservation_message']) ? 'block' : 'none'; ?>; /* Show the popup if reservation message is set */
        }
@media only screen and (max-width: 500px) {
    .reservation-form {
        width: 90%;
    }
}
        
    </style>
    
</head>
<body>
<header style="position:sticky;top:0;z-index:1;"class="header" id="myHeader">      
        <div class="max-width">
            <img class="logo1" style="z-index:1;" src="assets/image/mehlogo.png" >   
            <nav>
            <ul>
            <a class="home" href="index.php#home">Home</a>
            <a class="about" href="index.php#about">About</a>
            <a class="special" href="index.php#special">Speciality</a>
            <a class="service" href="index.php#service">Services</a>
            <a class="contact" href="index.php#contact">Contact</a>
            </ul>
            </nav>
            <i class="ri-menu-fold-fill" onclick="toggleMenu()"></i>
            </div>
        </div>
    </header>
    <div class="res">
    <h2>Hotel Table Reservation</h2>
    <div class="popup">
    <?php
    if (isset($_SESSION['reservation_message'])) {
        echo $_SESSION['reservation_message'];
        unset($_SESSION['reservation_message']); // Clear the session variable after displaying the message
    }
    ?>
    </div>

    <div>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']);?>" method="post" class="reservation-form">
        <div class="form-group">
            <label for="customer_name">Customer Name:</label>
            <input type="text" id="customer_name" name="customer_name" placeholder="Enter your name" required>
        </div>
        
        <div class="form-group">
            <label for="customer_contact">Customer Contact:</label>
            <input type="text" id="customer_contact" name="customer_contact" placeholder="Enter your 10 digit contact number" pattern="[0-9]{10}" title="Please enter a 10-digit contact number" required>
        </div>

        <div class="form-group">
            <label for="table_number">Table Number(1-24):</label>
            <input type="number" id="table_number" name="table_number" min="1" max="24" required>
        </div>

        <div class="form-group">
            <label for="reservation_date">Reservation Date:</label>
            <input type="date" id="reservation_date" name="reservation_date" required>
        </div>
        
        <div class="form-group">
            <label for="reservation_time">Reservation Time(Current time):</label>
            <input type="time" id="reservation_time" name="reservation_time" required>
        </div>
        <div class="form-group">
            <label for="start_time">Start Time:</label>
            <input type="time" id="start_time" name="start_time" required>
        </div>

        <div class="form-group">
            <label for="end_time">End Time:</label>
            <input type="time" id="end_time" name="end_time"  required>
        </div>

        <button type="submit" class="btn-submit">Reserve Table</button>
    </form>
    

    <footer class="main-footer" id="contact">
    <div class="f1">
        <div class="logo-f">
            <img src="assets/image/footerlogo.png" >
        </div>
        <div class="footer1">
            
            <h4 style="font-family:'Outfit';" >3X9V+87W, Alvas Hospital Rd, Mudbidri,</h4>
            <h4 style="font-family:'Outfit';" >Karnataka, India - 574227</h4>
            <h4 style="font-family:'Outfit';" >+91 123456789</h4>
            <h4 style="font-family:'Outfit';" >info@mehran.com</h4>
            <br><br>
            <a href="feedback.php" style=' background-color: #BDBB70 ;border-radius:5px;'><button class="feedback-btn" style="height:40px; width:100%;color:#182113; background-color:#BDBB70;border:none;font-size:18px;font-weight:900;font-family:'Outfit';">Feedback</button></a>
        
        </div>
    </div>
    <div class="footer-line1"></div>
    <div class="footer2">
        <ul> 
        <li><a style="font-family:'Outfit';" href="index.php#home">Home</a></li>
        <li><a style="font-family:'Outfit';" href="index.php#about">About</a></li>
        <li><a style="font-family:'Outfit';" href="index.php#special">Speciality</a></li>
        <li><a style="font-family:'Outfit';" href="index.php#service">Services</a></li>
        <li><a style="font-family:'Outfit';" href="index.php#contact">Contact</a></li>
        </ul>
       
    </div>
    <div class="footer-line1"></div>
    <div class="footer3"> 
        <div class="f-icons">
            <h4 style="font-family:'Outfit';" >Follow Us</h4>
            <a class="f-icon-links" href="https://www.instagram.com/_mehran_restaurant_?igsh=MWliOGswcmkxNHptNw=="><img src="assets/image/instagram-fill.png" alt="insta" /></a>
            <a class="f-icon-links" href="https://youtu.be/0jiWvc4Hleg?feature=shared"><img src="assets/image/youtube-fill.png" alt="insta" /></a>
            <a class="f-icon-links" href="https://www.facebook.com/profile.php?id=61556292725553&mibextid=ibOpuV"><img src="assets/image/facebook-circle-fill.png" alt="insta" /></a>
            <!-- <a class="f-icon-links" href="https://www.instagram.com/_mehran_restaurant_?igsh=MWliOGswcmkxNHptNw=="></a><img src="assets/image/linkedin-box-fill.png" alt="insta" /></a> -->
        </div>
        <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3886.4858248694422!2d74.99066947454807!3d13.068367212750388!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba4ab2ebfe44b07%3A0x5d19495b983e149e!2sMEHRAN%20RESTAURANT!5e0!3m2!1sen!2sin!4v1707459368169!5m2!1sen!2sin" width="100%" height="70%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</footer> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-parallax-js@5.5.1/dist/simpleParallax.min.js"></script>
</body>
</html>