<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reservation System</title>
    <link rel="stylesheet" href="templates/style.css">
    <style>
        /* Reset default styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    width:100%;
    height:100%;
    background-image:url(https://i.pinimg.com/564x/4c/88/f8/4c88f8142808c1d407852938bb3cffb7.jpg);
    /* background-image:url(https://i.pinimg.com/564x/21/21/d5/2121d5e6f58c6fe26c7677d854e4847d.jpg); */
    background-size: cover;
    background-position: center;
    /* background-repeat: no-repeat; */
    background-attachment: fixed;
    overflow-x: hidden;
    scroll-behavior: smooth;
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
}

header, h3{
    /* background-color: #032a0d; */
    color: #c4b350ee;
    padding: 10px;
    text-align: center;
}
h3{
    background-color: #032a0d;
}
h1 ,h3{
    font-size: 40px;   
}

main {
    display: flex;
    justify-content: center;
    align-items: center;
    height: calc(100vh - 80px); /* Adjusted for the header height */
}

.reservation-option {
    text-align: center;
}

.reservation-option h3 {
    font-size: 24px;
    margin-bottom: 20px;
}

.btn-reserve {
    display: inline-block;
    padding: 10px 20px;
    background-color: #4CAF50;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.btn-reserve:hover {
    background-color: #45a049;
}

    </style>
</head>
<body>
<header>      
        <div class="max-width">
            <img class="logo1" src="assets/image/mehlogo.png" >   
            <nav>
            <ul>
            <a class="home" href="#home">Home</a>
            <a class="about" href="#about">About</a>
            <a class="special" href="#special">Speciality</a>
            <a class="service" href="#service">Services</a>
            <a class="contact" href="#contact">Contact</a>
            </ul>
            </nav>
            <i class="ri-menu-fold-fill" onclick="toggleMenu()"></i>
            </div>
        </div>
    </header>
    <header>
        <h1>Reservation System</h1>
    </header>

    <main>
        <div class="reservation-option">
            <h3>To Reserve Table:</h3>
            <a href="reservation-table.php" class="btn-reserve">Check Availability And Reserve</a>
        </div>
    </main>
</body>
</html>
