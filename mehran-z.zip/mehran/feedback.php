<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <link rel="stylesheet" href="templates/style.css">
    <style>
        body {
            font-family: 'Outfit';
            background-color: #f3f3f3;
            margin: 0;
            padding: 0;
        
        }

        .container {
            width: 80%;
            max-width: 600px;
            margin-top:5%;
            margin-left:30%;
            margin-bottom:5%;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #555;
        }

        label {
            display: block;
            margin-bottom: 5px;
            color: #555;
        }

        input[type="text"],
        input[type="email"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            background-color: #f9f9f9;
        }

        textarea {
            resize: vertical;
            height: 100px;
        }

        input[type="submit"] {
            width: 100%;
            padding: 15px;
            border: none;
            border-radius: 5px;
            background-color: #6b8e23;
            color: #fff;
            font-size: 16px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #556b2f;
        }
    </style>
</head>
<body>
<header style="position:sticky;top:0;z-index:1;"class="header" id="myHeader">      
        <div class="max-width">
            <img class="logo1" style="z-index:1;" src="assets/image/mehlogo.png" >   
            <nav>
            <ul>
            <a class="home" href="index.php#home">Home</a>
            <a class="about" href="index.php#about">About</a>
            <a class="special" href="index.php#special">Speciality</a>
            <a class="service" href="index.php#service">Services</a>
            <a class="contact" href="index.php#contact">Contact</a>
            </ul>
            </nav>
            <i class="ri-menu-fold-fill" onclick="toggleMenu()"></i>
            </div>
        </div>
    </header>
    <div class="container">
        <h2>Feedback Form</h2>
        <form action="submit-feedback.php" method="post">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required><br>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required><br>

            <label for="rating">Rating:</label>
            <select id="rating" name="rating" required>
                <option value="1">1 - Poor</option>
                <option value="2">2 - Fair</option>
                <option value="3">3 - Average</option>
                <option value="4">4 - Good</option>
                <option value="5">5 - Excellent</option>
            </select><br>

            <label for="comment">Comment:</label><br>
            <textarea id="comment" name="comment" rows="4" cols="50"></textarea><br>

            <input type="submit" value="Submit">
        </form>
    </div>
    <footer class="main-footer" id="contact">
    <div class="f1">
        <div class="logo-f">
            <img src="assets/image/footerlogo.png" >
        </div>
        <div class="footer1">
            
            <h4 style="font-family:'Outfit';">3X9V+87W, Alvas Hospital Rd, Mudbidri,</h4>
            <h4 style="font-family:'Outfit';">Karnataka, India - 574227</h4>
            <h4 style="font-family:'Outfit';">+91 123456789</h4>
            <h4 style="font-family:'Outfit';">info@mehran.com</h4>
            <br><br>
            <!-- <button class="feedback-btn" style=' height:40px; width:80%;background-color:#BDBB70;border-radius:5px;'><a href="feedback.php" style=' background-color: #BDBB70 ;color:#182113; font-size:18px;font-weight:900;font-family: Outfit;'>Feedback</a></button> -->
        
        </div>
    </div>
    <div class="footer-line1"></div>
    <div class="footer2">
        <ul> 
        <li><a style="font-family:'Outfit';" href="index.php#home">Home</a></li>
        <li><a style="font-family:'Outfit';" href="index.php#about">About</a></li>
        <li><a style="font-family:'Outfit';" href="index.php#special">Speciality</a></li>
        <li><a style="font-family:'Outfit';" href="index.php#service">Services</a></li>
        <li><a style="font-family:'Outfit';" href="index.php#contact">Contact</a></li>
        </ul>
       
    </div>
    <div class="footer-line1"></div>
    <div class="footer3"> 
        <div class="f-icons">
        <li><a style="font-family:'Outfit';" href="index.php#contact">Contact</a></li>
            <h4 >Follow Us</h4>
            <a class="f-icon-links" href="https://www.instagram.com/_mehran_restaurant_?igsh=MWliOGswcmkxNHptNw=="><img src="assets/image/instagram-fill.png" alt="insta" /></a>
            <a class="f-icon-links" href="https://youtu.be/0jiWvc4Hleg?feature=shared"><img src="assets/image/youtube-fill.png" alt="insta" /></a>
            <a class="f-icon-links" href="https://www.facebook.com/profile.php?id=61556292725553&mibextid=ibOpuV"><img src="assets/image/facebook-circle-fill.png" alt="insta" /></a>
            <!-- <a class="f-icon-links" href="https://www.instagram.com/_mehran_restaurant_?igsh=MWliOGswcmkxNHptNw=="></a><img src="assets/image/linkedin-box-fill.png" alt="insta" /></a> -->
        </div>
        <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3886.4858248694422!2d74.99066947454807!3d13.068367212750388!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba4ab2ebfe44b07%3A0x5d19495b983e149e!2sMEHRAN%20RESTAURANT!5e0!3m2!1sen!2sin!4v1707459368169!5m2!1sen!2sin" width="100%" height="70%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</footer> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-parallax-js@5.5.1/dist/simpleParallax.min.js"></script>
</body>
</html>


