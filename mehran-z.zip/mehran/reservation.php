<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hotel_reservation";

$conn = new mysqli($servername, $username, $password, $dbname, 3307);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if($_SERVER["REQUEST_METHOD"] == "POST"){
// Form data
$customer_name = $_POST['customer_name'];
$customer_contact = $_POST['customer_contact'];
$reservation_date = $_POST['reservation_date'];
$reservation_time = $_POST['reservation_time'];

// Check availability
$sql = "SELECT * FROM reservations WHERE reservation_date = '$reservation_date' AND reservation_time = '$reservation_time'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "Table not available for the selected date and time.";
} else {
    // Insert reservation into database
    $sql = "INSERT INTO reservations (customer_name, customer_contact, reservation_date, reservation_time) VALUES ('$customer_name', '$customer_contact', '$reservation_date', '$reservation_time')";
    if ($conn->query($sql) === TRUE) {
        echo "Table reserved successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
}
$conn->close();
?>

