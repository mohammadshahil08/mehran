<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@4.1.0/fonts/remixicon.css" rel="stylesheet"/>
    <link rel="stylesheet" href="templates/style.css">
    
    <link rel="icon" href="assets/image/mehlogo.png" type="image/x-icon"/>
    <script  defer type="text/javascript" src="templates/script.js"></script>
    <title>Mehran Restaurant</title>
</head>
<body>  
    <!-- Navbar  -->
    <header style="position:sticky;top:0;z-index:1;"class="header" id="myHeader">      
        <div class="max-width">
            <img class="logo1" style="z-index:1;" src="assets/image/mehlogo.png" >   
            <nav>
            <ul>
            <a class="home" href="#home">Home</a>
            <a class="about" href="#about">About</a>
            <a class="special" href="#special">Speciality</a>
            <a class="service" href="#service">Services</a>
            <a class="contact" href="#contact">Contact</a>
            </ul>
            </nav>
            <i class="ri-menu-fold-fill" onclick="toggleMenu()"></i>
            </div>
        </div>
    </header>
<!-- Home -->
<div class="card"> 
    <section class="section1 section" id="home">
    <div class="blur">
        <div class="hero">
            <div class="img2warpper">
                <!-- <img class="img2" src="assets/image/kunafa.png"> -->
                <h1 class="ml2">GRAB-A-BITE</h1>
            </div>
            <br>
            <div class="img1warpper">
                <!-- <img class="img1" src="assets/image/hero1.png"> -->
                <div class="div1">
                    <p class="ml3">Indulge in the Flavors of the Arabia at <span>Mehran</span>, Where Every Bite Takes You to the Heart of Arabia.</p>
                </div>
            </div>
            <br>
            <div class="btn-div">
                <a class="btn-href" href="https://www.google.com/maps/place/MEHRAN+RESTAURANT/@13.0697629,74.9900292,17.46z/data=!4m6!3m5!1s0x3ba4ab2ebfe44b07:0x5d19495b983e149e!8m2!3d13.068362!4d74.9932444!16s%2Fg%2F11sd9dv2_r?hl=en&entry=ttu"><button class="btn1">Visit Now</button></a>
                <a class="btn-href" href="reservation-table.php"><button class="btn1">Reserve</button></a>
            </div>   
            <!-- <img src="assets/image/wave-haikei (1).png"> -->
        </div>
        <div class="hero-img">
        <img src="assets/image/hero-img1-removebg-preview.png" >  
    </div>
    </div>
    </section>
    <!-- About us -->
    <section class="section2 section" id="about"> 
            <div class="about-1">
                <div class="abt-div-flex">
                    <div class="about-div">
                        <h1>ABOUT US</h1> 
                    </div>
                    <div class="aboutp1">
                        <p>Mehran Restaurant offers an authentic Arabic dining experience with a wide range of delicious dishes. Our commitment to quality ingredients and customer service sets us apart. Our menu features a variety of dishes that will tantalize your taste buds, including our famous kunafa, juicy mutton, and succulent chicken.</p>
                    </div>
                </div>
                <br>
                <div class="aboutimg1 slide-in-fwd-center">
                    <img src="assets/image/about1.png">
                </div>
            </div>
            
        <div class="flex-1">
            <div class="aboutimg2 slide-in-fwd-center">
                <img src="assets/image/about2.png" width="299px" height="390px">
            </div>
           
            <div class="aboutp2">
                <p>Our menu is a symphony of aromatic spices, grilled meats, and mouthwatering mezze, showcasing the diverse and exquisite tastes of Arabic culinary artistry. From sumptuous kebabs to fragrant rice dishes, each plate is a celebration of flavors that transport you to the heart of the Arab world. Whether you're a connoisseur of traditional dishes or a newcomer to Arabic cuisine, our restaurant promises a dining experience that will leave your taste buds enchanted and satisfied.</p>
            </div>
        </div>
    </section> 

<!-- Specials -->
<section class="section3 section" id="special"> 
    <div class="services_div">
        <h1>OUR SPECIALS</h1> 
    </div>
    <div class="sp1">
        <div class="afghan-majlis">
            <img src="assets/image/afghan-majlis.png" alt="majlis">
            </div>
        <div class=sp-flex>
        <div class="rectangle-70">
            <div class="afghan-cuisine">
                <p><br>Afghan cuisine is a tapestry of rich flavors and aromas,weaving together spices like saffron, cardamom and coriander.In Mehran, you can experience both the Afghan cuisine and the Afghani Majlis.</div>
            </div>
            <div class="image-53">
                <img class="img" src="assets/image/image 53.png" alt="mandi">
            </div>
        </div>
    </div>
    <div>
        <div class="line-1">
            <img src="assets/image/Line 1.png" alt="l1">
        </div>
    </div>
    <div class="sp2">
        <div class="sp-flex2">
            <div class="image-52">
                <img class="img" src="assets/image/image 52.png" alt="mshawarmaa">
            </div>
            <div class="rectangle-71">
                <div class="shawarma-description"><p><br>Shawarma, a culinary delight popular in the Middle East,is a savory experience of thinly sliced, marinated meat.It’s specialty lies in its succulent, slow-cooked meat,harmoniously paired with vibrant flavors and wrapped in a comforting embrace of flatbread.</p></div> 
            </div>
        </div>
        <div class="munnas-shawarma">
            <img src="assets/image/munnas-shawarma 2.png" alt="mshawarma">
        </div>
        
    </div>
    <div>
        <div class="line-3">
            <img src="assets/image/Line 3.png" alt="l3">
        </div>
        <div class="line-4">
            <img src="assets/image/Line 1.png" alt="l4">
        </div>
    </div>
    <div class="sp3">
        <div class="crispy-bites">
            <img src="assets/image/crispy-bites.png" alt="cbites">
        </div>
        <div class="sp-flex3">
            <div class="rectangle-72">
                <div class="crispy-bites-description"><p><br>Crispy Bites offer a various range of crispy and crunchy items.The unique cooking method--pressure frying--ensures a delightful crunch,making each bite a savory delight.</p></div>
            </div>
            <div class="image-51">
                <img class="img" src="assets/image/image 51.png" alt="cbites">
            </div>
        </div>
        
    </div>
   
     <div>
        <div class="line-5">
            <img src="assets/image/Line 1.png" alt="l2">
        </div>
        <div class="line-6">
            <img src="assets/image/Line 1.png" alt="l2">
        </div>
    </div>
    <div>
    <div class="sp4">
        <div class="sp-flex4">
        <div class="image-50">
            <img class="img" src="assets/image/image 50.png" alt="jtruck">
          </div>
          <div class="rectangle-73">
            <div class="juice-truck-description"><p><br>Juice Truck offers a refreshing blend of nature’s sweetness, a sip of pure vitality. Juice is a vibrant liquid melody that transforms fruits into a symphony of flavors.</p></div>
          </div>
        </div>
          <div class="juice-truck">
          <img src="assets/image/juice-truck 2.png" alt="jtruck">
          </div>
    </div>
    </div>
</section>

<!-- Gallery -->
<section class="section-4 section">
        
        <div class="galbox1"></div>
        <div class="scroll-imgbx" style="--t:20s">
            
        <div>
            <img src="assets\image\mandi1.png" alt="1">
            <img src="assets\image\juce1.png" alt="1">
            <img src="assets\image\fries1.png" alt="1">
            <img class="img-w" src="assets\image\sha1.png" alt="1" width="175px">
            <img src="assets\image\mandi2.png" alt="2">
            <img src="assets\image\juice2.png" alt="2">
            <img src="assets\image\fries2.png" alt="2">
            <img class="img-w" src="assets\image\sha2.png" alt="2" width="175px"> 
        </div>
        <div>
            <img src="assets\image\mandi1.png" alt="1">
            <img src="assets\image\juce1.png" alt="1">
            <img src="assets\image\fries1.png" alt="1">
            <img class="img-w" src="assets\image\sha1.png" alt="1" width="175px">
            <img src="assets\image\mandi2.png" alt="2">
            <img src="assets\image\juice2.png" alt="2">
            <img src="assets\image\fries2.png" alt="2">
            <img class="img-w" src="assets\image\sha2.png" alt="2"width="175px">
        </div>
        </div>
        <div class="galbox2"></div>  
    
</section>

<section class="section5 section" id="service">
    <div class="services_div">
        <h1>OUR SERVICES</h1>
    </div>
    <div class="serv">
        <div class="servflex1">
            <div class="serv1-img1">
                <img class="pulsate-bck" src="assets\image\image 21.png">
            </div>
            <div class="serv1-img2">
                <img src="assets\image\image 79.png">
                <div class="serv-rect1">
                    <div class="aest-rect1">
                        <div class="aest-rect2">AESTHETIC PARTY HALL</div>
                            Elegance meets celebration in this aesthetic party hall, where every detail is a brushstroke of sophistication, creating a canvas of unforgettable moments. The ambient lighting dances on walls adorned with tasteful decor, setting the stage for a night where style and festivities intertwine.
                    </div>
                </div>
            </div>
        </div>
        <div class="servflex2">
            <div class="serv2-img1">
                <img  src="assets\image\image 78.png">
                <div class="serv-rect2">
                    <div class="beauty-rect1">
                        <div class="beauty-rect2">BEAUTIFUL DINING HALL</div>
                        In this beautiful dining hall, the tables are adorned with gleaming tableware, creating a refined atmosphere for delights and delightful conversations. Under the soft glow of light, the beautiful dining hall becomes a symphony of culinary artistry, where flavors mingle and laughter resonates.
                    </div>
                </div>
            </div>
            <div class="serv2-img2">
                <img class="pulsate-bck" src="assets\image\image 23.png">
            </div>
        </div>
    </div>
</section>


<!-- Testimonials -->
<section class="section-6 section">
    <div><center><h1>TESTIMONIALS</h1></center></div>
    <div class="reviews-flex">
        <div class="testimonial active">
            <div class="test-flex">
                <div class="rect-3"></div>
                <div class="rect-1">
                    <img src="assets/image/review1.png">
                    <h3>Pranam Rai</h3>
                </div>
                <div class="rect-p">
                    <p>One of the best place in Moodbidri with good ambience and delicious food. Baby kabab is the killer item which you can select here. You can have Afghani foods available here which do taste good. They have delicious shawarma which is unique. If planing to have a party then kunafa is the last desert that you should never miss, mainly the mozerela cheese kunafa the best.</p>     
                </div>  
                <!-- <div class="arrows">                     
                    <i class="ri-arrow-left-s-fill"></i>
                    <i class="ri-arrow-right-s-fill"></i>
                </div>   -->
            </div>   
        </div>
        <div class="testimonial">
            <div class="test-flex">
                <div class="rect-3"></div>
                <div class="rect-1">
                    <img src="assets/image/review2.png">
                    <h3>Rahil Rahil</h3>
                </div>
                <div class="rect-p">
                    <p>Mehran Bistro truly impressed! The cozy atmosphere paired with outstanding service made for a memorable evening. Their signature dish, the grilled platter , was exquisite—cooked to perfection! While the menu is fantastic, a few more vegetarian options would add to its appeal. Overall, a top-notch experience worth revisiting.</p>     
                </div>  
                <!-- <div class="arrows">                     
                    <i class="ri-arrow-left-s-fill"></i>
                    <i class="ri-arrow-right-s-fill"></i>
                </div>   -->
            </div>   
        </div>
        <div class="testimonial">
            <div class="test-flex">
                <div class="rect-3"></div>
                <div class="rect-1">
                    <img src="assets/image/review3.png">
                    <h3> Frederick Laisharam</h3>
                </div>
                <div class="rect-p">
                    <p>Food is really good especially fairy tawa wings which i love so much because of it's spicy taste. Waiters are also friendly. The atmosphere is really good.</p>     
                </div>  
                <!-- <div class="arrows">                     
                    <i class="ri-arrow-left-s-fill"></i>
                    <i class="ri-arrow-right-s-fill"></i>
                </div>   -->
            </div>   
        </div>
        <div class="testimonial">
            <div class="test-flex">
                <div class="rect-3"></div>
                <div class="rect-1">
                    <img src="assets/image/review4.png">
                    <h3> Prajwal kp </h3>
                </div>
                <div class="rect-p">
                    <p>Pure Arabian restaurant. One of the best al faham, grill chicken and mutton chops tasted ever. Mandi you get in 3 different sizes which full, half and quarter which really helps the family of smaller size and pieces you get enough basis the sizes and also rice quantity was satisfactory for the price of 220. Last but not least the kunafa was really well.</p>     
                </div>  
                <!-- <div class="arrows">                     
                    <i class="ri-arrow-left-s-fill"></i>
                    <i class="ri-arrow-right-s-fill"></i>
                </div>   -->
            </div>   
        </div>

        <div id="next" class="ri-arrow-right-s-fill" onclick="next()"></div>
        <div id="prew" class="ri-arrow-left-s-fill" onclick="prew()"></div>
        
    </div>
    <!-- <div><center><h1>TESTIMONALS</h1></center></div>
    <div class="reviews-flex">
        <div class="testimonial-1">
            <div class="test-flex">
                <div class="rect-3"></div>
                <div class="rect-1">
                    <img src="assets/image/review1.png">
                    <h3>Pranam Rai</h3>
                </div>
                <div class="rect-p">
                    <p>One of the best places in Moodbidri with good ambience and delicious food. Baby kabab is the killer item which you can select here ,tasty and delicious. You can have Afghani foods available here which do taste good. They have huge space you can go with family and have a party time. They have delicious shawarma which is one of the unique you can get. If planing to have a party then kunafa is the last desert that you should never miss.. mainly the mozerela cheese kunafa the best.. they do have delivery service.</p>     
                </div>  
                <div class="arrows">                     
                    <i class="ri-arrow-left-s-fill"></i>
                    <i class="ri-arrow-right-s-fill"></i>
                </div>  
            </div>   
        </div>
        <div class="testimonial-2">
            <div class="test-flex">
                <div class="rect-3"></div>
                <div class="rect-1">
                    <img src="assets/image/review1.png">
                    <h3>Pranam Rai</h3>
                </div>
                <div class="rect-p">
                    <p>One of the best places in Moodbidri with good ambience and delicious food. Baby kabab is the killer item which you can select here ,tasty and delicious. You can have Afghani foods available here which do taste good. They have huge space you can go with family and have a party time. They have delicious shawarma which is one of the unique you can get. If planing to have a party then kunafa is the last desert that you should never miss.. mainly the mozerela cheese kunafa the best.. they do have delivery service.</p>     
                </div>  
                <div class="arrows">                     
                    <i class="ri-arrow-left-s-fill"></i>
                    <i class="ri-arrow-right-s-fill"></i>
                </div>  
            </div>   
        </div>
        <div class="testimonial-3">
            <div class="test-flex">
                <div class="rect-3"></div>
                <div class="rect-1">
                    <img src="assets/image/review1.png">
                    <h3>Pranam Rai</h3>
                </div>
                <div class="rect-p">
                    <p>One of the best places in Moodbidri with good ambience and delicious food. Baby kabab is the killer item which you can select here ,tasty and delicious. You can have Afghani foods available here which do taste good. They have huge space you can go with family and have a party time. They have delicious shawarma which is one of the unique you can get. If planing to have a party then kunafa is the last desert that you should never miss.. mainly the mozerela cheese kunafa the best.. they do have delivery service.</p>     
                </div>  
                <div class="arrows">                     
                    <i class="ri-arrow-left-s-fill"></i>
                    <i class="ri-arrow-right-s-fill"></i>
                </div>  
            </div>   
        </div>
        <div class="testimonial-4">
            <div class="test-flex">
                <div class="rect-3"></div>
                <div class="rect-1">
                    <img src="assets/image/review1.png">
                    <h3>Pranam Rai</h3>
                </div>
                <div class="rect-p">
                    <p>One of the best places in Moodbidri with good ambience and delicious food. Baby kabab is the killer item which you can select here ,tasty and delicious. You can have Afghani foods available here which do taste good. They have huge space you can go with family and have a party time. They have delicious shawarma which is one of the unique you can get. If planing to have a party then kunafa is the last desert that you should never miss.. mainly the mozerela cheese kunafa the best.. they do have delivery service.</p>     
                </div>  
                <div class="arrows">                     
                    <i class="ri-arrow-left-s-fill"></i>
                    <i class="ri-arrow-right-s-fill"></i>
                </div>  
            </div>   
        </div>
    </div> -->
</section>
</div>
<!-- footer -->
 <footer class="main-footer" id="contact">
    <div class="f1">
        <div class="logo-f">
            <img src="assets/image/footerlogo.png" >
        </div>
        <div class="footer1">
            
            <h4>3X9V+87W, Alvas Hospital Rd, Mudbidri,</h4>
            <h4>Karnataka, India - 574227</h4>
            <h4>+91 123456789</h4>
            <h4>info@mehran.com</h4>
            <br><br>
            <a href="feedback.php" style=' background-color: #BDBB70 ;border-radius:5px;'><button class="feedback-btn" style="height:40px; width:100%;color:#182113; background-color:#BDBB70;border:none;font-size:18px;font-weight:900;font-family:'Outfit';">Feedback</button></a>
        
        </div>
    </div>
    <div class="footer-line1"></div>
    <div class="footer2">
        <ul> 
        <li><a href="#home">Home</a></li>
        <li><a href="#about">About</a></li>
        <li><a href="#special">Speciality</a></li>
        <li><a href="#service">Services</a></li>
        <li><a href="#contact">Contact</a></li>
        </ul>
       
    </div>
    <div class="footer-line1"></div>
    <div class="footer3"> 
        <div class="f-icons">
            <h4>Follow Us</h4>
            <a class="f-icon-links" href="https://www.instagram.com/_mehran_restaurant_?igsh=MWliOGswcmkxNHptNw=="><img src="assets/image/instagram-fill.png" alt="insta" /></a>
            <a class="f-icon-links" href="https://youtu.be/0jiWvc4Hleg?feature=shared"><img src="assets/image/youtube-fill.png" alt="insta" /></a>
            <a class="f-icon-links" href="https://www.facebook.com/profile.php?id=61556292725553&mibextid=ibOpuV"><img src="assets/image/facebook-circle-fill.png" alt="insta" /></a>
            <!-- <a class="f-icon-links" href="https://www.instagram.com/_mehran_restaurant_?igsh=MWliOGswcmkxNHptNw=="></a><img src="assets/image/linkedin-box-fill.png" alt="insta" /></a> -->
        </div>
        <div class="map">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3886.4858248694422!2d74.99066947454807!3d13.068367212750388!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba4ab2ebfe44b07%3A0x5d19495b983e149e!2sMEHRAN%20RESTAURANT!5e0!3m2!1sen!2sin!4v1707459368169!5m2!1sen!2sin" width="100%" height="70%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
</footer> 

<script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/2.0.2/anime.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/simple-parallax-js@5.5.1/dist/simpleParallax.min.js"></script>

<!-- <script  type="text/javascript" src="script.js"></script> -->
</body>
</html>
